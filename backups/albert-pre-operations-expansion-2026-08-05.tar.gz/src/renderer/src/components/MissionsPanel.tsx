import { useMemo, useState } from 'react'

type MissionState = 'active' | 'queued' | 'approval' | 'complete'

interface Mission {
  id: string
  title: string
  detail: string
  state: MissionState
  progress: number
  eta: string
  agent: string
  steps: string[]
}

const seedMissions: Mission[] = [
  {
    id: 'morning-brief',
    title: 'Morning intelligence brief',
    detail: 'Calendar, priority mail, weather, project drift, and one recommended first move.',
    state: 'complete',
    progress: 100,
    eta: 'Delivered 08:02',
    agent: 'BRIEFING',
    steps: ['Calendar scanned', 'Inbox triaged', 'Project status synthesized']
  },
  {
    id: 'release-audit',
    title: 'Audit ALBERT release readiness',
    detail: 'Run checks, inspect packaging risks, and prepare a ship / hold recommendation.',
    state: 'active',
    progress: 68,
    eta: '6 min remaining',
    agent: 'ENGINEERING',
    steps: ['Typecheck passed', 'Bundle analysis running', 'Packaging review queued']
  },
  {
    id: 'flight-watch',
    title: 'Watch ORD → SFO fares',
    detail: 'Check twice daily and alert only when a nonstop option drops below $320.',
    state: 'queued',
    progress: 20,
    eta: 'Next scan 18:00',
    agent: 'WATCHTOWER',
    steps: ['Threshold armed', 'Three sources connected', 'No qualifying change']
  },
  {
    id: 'expenses',
    title: 'Prepare July expense packet',
    detail: 'Match receipts, classify purchases, and stage the final packet for review.',
    state: 'approval',
    progress: 91,
    eta: 'Waiting on you',
    agent: 'OPERATIONS',
    steps: ['24 receipts matched', 'Two exceptions flagged', 'Submission requires approval']
  }
]

const routines = [
  { time: '08:00', name: 'Daily briefing', status: 'armed' },
  { time: '12:30', name: 'Deep-work shield', status: 'armed' },
  { time: '18:00', name: 'Watchtower sweep', status: 'armed' },
  { time: 'FRI', name: 'Weekly review', status: 'draft' }
]

export function MissionsPanel(): React.JSX.Element {
  const [filter, setFilter] = useState<'all' | MissionState>('all')
  const [selectedId, setSelectedId] = useState('release-audit')
  const [missions, setMissions] = useState(seedMissions)
  const [briefingOpen, setBriefingOpen] = useState(true)

  const visible = useMemo(
    () => missions.filter((mission) => filter === 'all' || mission.state === filter),
    [filter, missions]
  )
  const selected = missions.find((mission) => mission.id === selectedId) ?? missions[0]
  const activeCount = missions.filter((mission) => mission.state === 'active').length
  const approvalCount = missions.filter((mission) => mission.state === 'approval').length

  function approveSelected(): void {
    setMissions((current) =>
      current.map((mission) =>
        mission.id === selected.id
          ? { ...mission, state: 'complete', progress: 100, eta: 'Approved just now' }
          : mission
      )
    )
  }

  return (
    <section className="panel missions-panel">
      <header className="missions-header">
        <div>
          <div className="eyebrow">PROACTIVE OPERATIONS / CONCEPT PREVIEW</div>
          <h2 className="section-title">Missions</h2>
          <p className="section-sub">Objectives Albert can plan, execute, watch, and escalate.</p>
        </div>
        <button className="btn primary" type="button" onClick={() => setBriefingOpen((open) => !open)}>
          {briefingOpen ? 'Hide briefing' : 'Open briefing'}
        </button>
      </header>

      <div className="mission-kpis" aria-label="Mission summary">
        <Kpi label="Active agents" value={String(activeCount).padStart(2, '0')} note="within policy" tone="live" />
        <Kpi label="Awaiting approval" value={String(approvalCount).padStart(2, '0')} note="human checkpoint" tone="warn" />
        <Kpi label="Automations" value="04" note="3 armed · 1 draft" />
        <Kpi label="Time recovered" value="3.4H" note="this week" />
      </div>

      {briefingOpen ? (
        <article className="daily-brief">
          <div className="brief-mark"><span>05</span><small>AUG</small></div>
          <div className="brief-copy">
            <div className="eyebrow">SITUATION REPORT / 08:02</div>
            <h3>Good morning, Kai. Your runway is clear until 11:30.</h3>
            <p>
              The release audit is the highest-leverage move. One expense packet needs approval,
              and your flight watch remains above threshold. No critical system faults detected.
            </p>
          </div>
          <div className="brief-actions">
            <button type="button" className="text-action">▶ Play brief</button>
            <button type="button" className="text-action">Open focus plan →</button>
          </div>
        </article>
      ) : null}

      <div className="mission-workspace">
        <div className="mission-board">
          <div className="mission-toolbar">
            <div className="filter-row">
              {(['all', 'active', 'approval', 'queued', 'complete'] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  className={filter === item ? 'active' : ''}
                  onClick={() => setFilter(item)}
                >
                  {item}
                </button>
              ))}
            </div>
            <span>{visible.length} OBJECTIVES</span>
          </div>

          <div className="mission-list">
            {visible.map((mission) => (
              <button
                type="button"
                key={mission.id}
                className={`mission-card ${selected.id === mission.id ? 'selected' : ''}`}
                onClick={() => setSelectedId(mission.id)}
              >
                <div className={`mission-state ${mission.state}`}>{mission.state}</div>
                <div className="mission-card-copy">
                  <div className="mission-card-heading">
                    <h3>{mission.title}</h3><span>{mission.agent}</span>
                  </div>
                  <p>{mission.detail}</p>
                  <div className="mission-progress"><i style={{ width: `${mission.progress}%` }} /></div>
                  <div className="mission-meta"><span>{mission.progress}% COMPLETE</span><span>{mission.eta}</span></div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <aside className="mission-inspector">
          <div className="eyebrow">OBJECTIVE DETAIL / {selected.id.toUpperCase()}</div>
          <div className={`inspector-sigil ${selected.state}`}><span>{selected.progress}</span><small>%</small></div>
          <h3>{selected.title}</h3>
          <p>{selected.detail}</p>
          <div className="step-stack">
            {selected.steps.map((step, index) => (
              <div key={step} className={index < Math.ceil(selected.progress / 34) ? 'done' : ''}>
                <span>{String(index + 1).padStart(2, '0')}</span>{step}
              </div>
            ))}
          </div>
          {selected.state === 'approval' ? (
            <div className="approval-box">
              <span>HUMAN CHECKPOINT</span>
              <p>Albert has staged the result but will not submit it without your authorization.</p>
              <button className="btn primary" type="button" onClick={approveSelected}>Approve & continue</button>
            </div>
          ) : (
            <button className="btn ghost inspector-button" type="button">Open mission log</button>
          )}
        </aside>
      </div>

      <section className="routine-strip">
        <div className="routine-heading"><span className="eyebrow">AUTOMATION GRID</span><button type="button">Configure →</button></div>
        <div className="routine-grid">
          {routines.map((routine) => (
            <article key={routine.name}>
              <strong>{routine.time}</strong><div><span>{routine.name}</span><small>{routine.status}</small></div>
            </article>
          ))}
        </div>
      </section>
    </section>
  )
}

function Kpi({ label, value, note, tone = '' }: { label: string; value: string; note: string; tone?: string }): React.JSX.Element {
  return <article className={`mission-kpi ${tone}`}><span>{label}</span><strong>{value}</strong><small>{note}</small></article>
}
