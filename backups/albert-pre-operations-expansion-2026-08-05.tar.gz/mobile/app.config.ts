import type { ExpoConfig } from 'expo/config'

const config: ExpoConfig = {
  name: 'A.L.B.E.R.T.',
  slug: 'albert',
  owner: 'kaichik',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  userInterfaceStyle: 'dark',
  scheme: 'albert',
  ios: {
    supportsTablet: true,
    bundleIdentifier: 'com.kaichik.albert',
    buildNumber: '1',
    infoPlist: {
      NSMicrophoneUsageDescription:
        'A.L.B.E.R.T. needs the microphone for wake, voice chat, and mute.',
      NSSpeechRecognitionUsageDescription:
        'A.L.B.E.R.T. uses on-device speech recognition for wake phrases and voice commands.',
      NSLocalNetworkUsageDescription:
        'A.L.B.E.R.T. connects to your Mac on the local network to sync Comm and memories.',
      // Required by App Store even when only a linked SDK references Photos APIs
      NSPhotoLibraryUsageDescription:
        'A.L.B.E.R.T. may access your photo library if you choose to attach an image in Comm.',
      NSPhotoLibraryAddUsageDescription:
        'A.L.B.E.R.T. may save images to your photo library when you choose to export one.',
      ITSAppUsesNonExemptEncryption: false,
      NSAppTransportSecurity: {
        NSAllowsLocalNetworking: true,
        NSAllowsArbitraryLoads: true
      }
    }
  },
  android: {
    package: 'com.kaichik.albert',
    adaptiveIcon: {
      foregroundImage: './assets/adaptive-icon.png',
      backgroundColor: '#000000'
    },
    permissions: ['RECORD_AUDIO']
  },
  web: {
    favicon: './assets/favicon.png'
  },
  extra: {
    eas: {
      projectId: process.env.EAS_PROJECT_ID || '3b312788-2ec0-45da-83d7-e88014d9c9ef'
    }
  },
  plugins: [
    'expo-secure-store',
    'expo-font',
    'expo-asset',
    [
      'expo-speech-recognition',
      {
        microphonePermission:
          'A.L.B.E.R.T. needs the microphone for wake, voice chat, and mute.',
        speechRecognitionPermission:
          'A.L.B.E.R.T. uses speech recognition for wake phrases and voice commands.'
      }
    ]
  ]
}

export default config
